import java.awt.Color;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.RowSorter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

class InquireDialog extends JDialog implements ActionListener {

	private StudentGUIDesign gui;
	private StudentDAO dao;
	private JTextField tf = new JTextField(20);
	JTextArea ta = new JTextArea();
	private JScrollPane scroll;
	private JTextField d_tf_id = new JTextField(20); // id
	private JPanel p;

	JScrollPane scrollPane;
	private JButton d_bt_id = new JButton("학번 검색");
	private JButton d_bt_fullscore = new JButton("전체 성적출력");
	private JButton d_bt_name = new JButton("이름순으로 검색");

	private JButton d_bt_save = new JButton("저장하기");
	private JButton d_bt_invoke = new JButton("불러오기");

	private JButton d_bt_cancel = new JButton("종료");
	private StudentGUIDesign stf;
	private JFileChooser fc = new JFileChooser();

	ImageIcon icon = new ImageIcon("images/inquireBackground.png");

	String[] colNames = new String[] { "ID", "이름", "JAVA", "C", "HTML", "평균점수" };

	TableModel model = new DefaultTableModel(colNames, 0) {
		public Class getColumnClass(int column) {
			Class returnValue;
			if ((column >= 0) && (column < getColumnCount())) {
				returnValue = getValueAt(0, column).getClass();
			} else {
				returnValue = Object.class;
			}
			return returnValue;
		}
	};
	JTable table = new JTable(model);

	InquireDialog(JFrame frame, StudentDAO dao) {
		super(frame, "조회", true);
		this.dao = dao;
		Dimension frameSize = this.getSize();
		Dimension windowSize = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((windowSize.width - frameSize.width) / 3, (windowSize.height - frameSize.height) / 3);
		this.dialogDesign();
		this.dialogEvent();
		this.setSize(680, 500);
	}

	public void dialogDesign() {
		p = new JPanel() {
			public void paintComponent(Graphics g) {
				g.drawImage(icon.getImage(), 0, 0, null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		
		this.add(p);
		p.setLayout(null);

// --------------------------------------------
		d_tf_id.setSize(70, 25);
		d_tf_id.setLocation(60, 70);
		p.add(d_tf_id);

		RowSorter<TableModel> sorter = new TableRowSorter<TableModel>(model);
		table.setRowSorter(sorter);
		JScrollPane scrollPane = new JScrollPane(table);

		p.add(scrollPane);
		this.pack();
		scrollPane.setLocation(60, 100);
		scrollPane.setSize(500, 150);
		scrollPane.setBorder(BorderFactory.createEmptyBorder());

		scrollPane.getViewport().setBackground(Color.WHITE);

		p.add(d_bt_id);
		d_bt_id.setBounds(135, 70, 100, 27);
		p.add(d_bt_fullscore);
		d_bt_fullscore.setBounds(440, 70, 120, 27);
		p.add(d_bt_cancel);
		d_bt_cancel.setBounds(270, 350, 80, 30);
		p.add(d_bt_save);
		d_bt_save.setBounds(370, 260, 90, 27);
		p.add(d_bt_invoke);
		d_bt_invoke.setBounds(470, 260, 90, 27);

		d_bt_id.setBackground(new Color(130, 199, 254));
		d_bt_id.setForeground(Color.white);

		d_bt_fullscore.setBackground(new Color(130, 199, 254));
		d_bt_fullscore.setForeground(Color.white);

		d_bt_cancel.setBackground(new Color(0, 0, 0));
		d_bt_cancel.setForeground(Color.white);

		d_bt_save.setBackground(new Color(130, 199, 254));
		d_bt_save.setForeground(Color.white);

		d_bt_invoke.setBackground(new Color(130, 199, 254));
		d_bt_invoke.setForeground(Color.white);
	}

	public void dialogEvent() {
		d_bt_name.addActionListener(this);
		d_bt_id.addActionListener(this);
		d_bt_fullscore.addActionListener(this);
		d_bt_cancel.addActionListener(this);
		d_bt_save.addActionListener(this);
		d_bt_invoke.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == d_bt_id) {
			boolean found = false;
			((DefaultTableModel) model).setNumRows(0);
			for (int i = 0; i < dao.list.size(); i++) {

				ta.setText("");
				Student stu = dao.list.get(i);
				if (d_tf_id.getText().equals(stu.getId())) {
					String[] rows = new String[6];
					rows[0] = dao.list.get(i).getId(); // ID
					rows[1] = dao.list.get(i).getName(); // 이름
					rows[2] = "" + dao.list.get(i).getJAVA(); // JAVA
					rows[3] = "" + dao.list.get(i).getC(); // C
					rows[4] = "" + dao.list.get(i).getHTML(); // HTML
					rows[5] = ""
							+ (dao.list.get(i).getC() + dao.list.get(i).getJAVA() + dao.list.get(i).getHTML())
									/ 3; // 평균
					((DefaultTableModel) model).addRow(rows);
					d_tf_id.setText("");
					found = true;
					return;
				} else {
				}
			}
			if (!found) {
				JOptionPane.showMessageDialog(null, "일치하는 정보가 없습니다", "", JOptionPane.OK_CANCEL_OPTION);
			}
		}
//------------------------------------------------------------------------------------------------------------------------------------저장하기	
		else if (e.getSource() == d_bt_save) {
			FileNameExtensionFilter filter = new FileNameExtensionFilter("TXT", "txt");
			fc.setFileFilter(filter);

			int ret = fc.showSaveDialog(null); // 열기파일 다이얼로그 출력
			if (ret != JFileChooser.APPROVE_OPTION) {
				JOptionPane.showMessageDialog(null, "파일을 선택하지 않았습니다", "경고", JOptionPane.WARNING_MESSAGE);
				return;
			}
			// 사용자가 저장 버튼을 누른 경우
			String filePath = fc.getSelectedFile().getPath();
			FileWriter fw = null;
			try {
				fw = new FileWriter(filePath);
				fw.write(table.getRowCount() + "\n"); // 저장할 내용의 테이블 갯수를 구한다.
				for (int i = 0; i < table.getRowCount(); i++) {
					for (int j = 0; j < table.getColumnCount(); j++) {
						fw.write((String) table.getValueAt(i, j) + "\n");
						// 각 열과 행에 행당값을 저장한다.
					}
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} finally {
				try {
					fw.close(); // 파일 쓰기가 끝나면 꼭 닫아 줘야 한다.
				} catch (IOException e1)

				{
					e1.printStackTrace();
				}
			}
		}
//------------------------------------------------------------------------------------------------------------------------------------불러오기
		else if (e.getSource() == d_bt_invoke) {
			
			((DefaultTableModel) model).setRowCount(0);// 테이블을 초기화 한다.
			FileNameExtensionFilter filter = new FileNameExtensionFilter("TXT", "txt");
			fc.setFileFilter(filter);

			int ret = fc.showOpenDialog(null); // 열기파일 다이얼로그 출력
			if (ret != JFileChooser.APPROVE_OPTION) {
				JOptionPane.showMessageDialog(null, "파일을 선택하지 않았습니다", "경고", JOptionPane.WARNING_MESSAGE);
				return;
			}
			String filePath = fc.getSelectedFile().getPath();
			try {
				BufferedReader br = new BufferedReader(new FileReader(filePath));
				int cnt = Integer.parseInt(br.readLine()); // 파일에 저장된 내용을 줄 단위로 읽어온다.
				for (int i = 0; i < cnt; i++) // Row 를 먼저 읽어 읽는다.
				{
					String str[] = new String[6];

					for (int j = 0; j < 6; j++) // 들어갈 내용의 항목이 6개 이므로 6번 읽는다.
					{
						str[j] = br.readLine();
					}
					((DefaultTableModel) model).addRow(str); // 테이블에 추가시킨다.
					Student stu1 = new Student(str[0], str[1], Integer.parseInt(str[2]), Integer.parseInt(str[3]),
							Integer.parseInt(str[4]));
					dao.list.add(stu1);
				}
				br.close();// 불러오기가 끝난후 종료
			} catch (Exception e1) {
				JOptionPane.showMessageDialog(this, "열기 오류");
			}

		} else if (e.getSource() == d_bt_fullscore) {
			((DefaultTableModel) model).setNumRows(0);
			if (dao.list.size() < 1) {
				JOptionPane.showMessageDialog(null, "입력한  정보가 없습니다", "", JOptionPane.OK_CANCEL_OPTION);
			}
			Collections.sort(dao.list, new Gradecomparison());
			ta.setText("");
			for (int i = 0; i < dao.list.size(); i++) {
				String[] rows = new String[6];
				rows[0] = dao.list.get(i).getId(); // ID
				rows[1] = dao.list.get(i).getName(); // 이름
				rows[2] = "" + dao.list.get(i).getJAVA(); // JAVA
				rows[3] = "" + dao.list.get(i).getC(); // C
				rows[4] = "" + dao.list.get(i).getHTML(); // HTML
				rows[5] = ""
						+ (dao.list.get(i).getC() + dao.list.get(i).getJAVA() + dao.list.get(i).getHTML()) / 3; // 평균
				((DefaultTableModel) model).addRow(rows);
			}
		} else if (e.getSource() == d_bt_cancel) {
			d_tf_id.setText("");
			InquireDialog.this.setVisible(false);
		}
	}
}
