import java.io.Serializable;


//Student 클래스
//학생 각각의 정보는 하나의 Student 데이터의 객체가 된다.

public class Student implements Comparable<Student>, Serializable {
	private String id; // 학번
	private String name; // 이름
	private int JAVA; // JAVA
	private int C; // C
	private int HTML; // HTML

	public Student(String id, String name, int JAVA, int C, int HTML) {
		this.id = id;
		this.name = name;
		this.JAVA = JAVA;
		this.C = C;
		this.HTML = HTML;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getJAVA() {
		return JAVA;
	}


	public void setJAVA(int jAVA) {
		JAVA = jAVA;
	}


	public int getC() {
		return C;
	}


	public void setC(int c) {
		C = c;
	}


	public int getHTML() {
		return HTML;
	}


	public void setHTML(int hTML) {
		HTML = hTML;
	}


	public boolean equals(Student stu) {
		boolean result = false;
		if (id.equals(stu.id)) 
			return true;
		return result;
	}

	@Override
	public int compareTo(Student o) {
		return name.compareTo(o.name);
	}
	// Comparable<T> 인터페이스
	// Comparable 인터페이스는 객체를 정렬하는데 사용되는 compareTo() 메소드를 정의하고있다.


}