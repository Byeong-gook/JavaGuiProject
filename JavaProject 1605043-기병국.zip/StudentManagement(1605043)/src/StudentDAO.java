import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Scanner;


/*
* StudentDAO 클래스
* 학생관리시스템에서 요구하는 기능을 처리하는 객체를 만드는 클래스
* ArrayList 콜렉션 이용
*/
public class StudentDAO {
	private Scanner scan; //입력받는 변수
	ArrayList<Student> list; // 학생리스트
	private String id; // 학생 학번
	private String name; // 학생 이름
	private int score; // 학생 성적

	public StudentDAO() {
		scan = new Scanner(System.in);
		list = new ArrayList<Student>();
	}

//1. 등록
//	public void insert() {
//		System.out.println("학번을 입력");
//		id = scan.nextLine();
//
//		for (int i=0; i < list.size(); i++) {
//			Student stu = list.get(i); 
//			if (id.equals(stu.getId())) { 
//				//사용자가입력한 학번과 비교해서 이미 존재하면 학번이라면 리턴  
//				System.out.println("이미 존재하는id입니다.");
//				return;
//			}
//		}
//		System.out.println("이름 입력");
//		name = scan.nextLine();
//		System.out.println("성적을 입력");
//		score = Integer.parseInt(scan.nextLine());
//		// 숫자형의 문자열을 인자값으로 받으면 해당 값을 10진수의 Integer 형으로 반환 해준다.
//		try {
//			if (score > 100 || score < 0) { //100점을 초과하거나 0점 미만의 값을 입력하면 예외발생
//				throw new NumberFormatException("0과 100사이의 점수를 입력 해주세요.");
//			} else {
//				Student stu = new Student(id, name, score);
//				list.add(stu); //정상적으로 값이 입력됐다면  학생리스트에 객체 추가
//			}
//		} catch (NumberFormatException e) {
//			System.out.println("에러발생! 0과 100 사이의 점수를 입력해주세요");
//		}
//	}
	
	//1. 등록
	public void input(String tf_id, String tf_name, int tf_JAVA, int tf_C, int tf_HTML) {
		for (int i = 0; i < list.size(); i++) {
			Student stu = list.get(i);
			if (tf_id.equals(stu.getId())) {
				System.out.println("이미 존재하는 학번입니다.");
				return;
			}
		}

		if (tf_JAVA >= 0 && tf_JAVA <= 100) {
			Student stu = new Student(tf_id, tf_name, tf_JAVA, tf_C, tf_HTML);
			list.add(stu);
			Student stu1 = new Student("160001", "김진우", 80, 70, 90);
			list.add(stu1);
			Student stu2 = new Student("160002", "구태호", 95, 95, 100);
			list.add(stu2);
			Student stu3 = new Student("160003", "김재년", 10, 50, 20);
			list.add(stu3);
			System.out.println("등록 완료");
		} else {
			System.out.println("0부터 100사이의 숫자만 입력하세요.");
		}

	}

	// 2. 조회
	public void inqure() {
		for (int i = 0; i < list.size(); i++) {
			System.out.println(
					"ID : "+list.get(i).getId()+"이름 : " +list.get(i).getName()+ "성적 : " +list.get(i).getJAVA());
		} 
	}

	// 3. 수정 메뉴
	public void update() {
		System.out.println("수정할 학생 ID: ");
		String up_id = scan.nextLine();
		boolean found = false;
		int tempIndex = 0;

		for (int i = 0; i < list.size(); i++) {
			Student stu = list.get(i);
			if (up_id.equals(stu.getId())) {
				found = true;
				tempIndex = i;

				break;
			}
		}
		if (found) {
			System.out.println("수정ID : ");
			String new_id = scan.nextLine();

			System.out.println("수정할 이름 : ");
			String new_name = scan.nextLine();

			System.out.println("수정할 성적 : ");
			int new_JAVA = scan.nextInt();

			System.out.println("수정할 성적 : ");
			int new_C = scan.nextInt();
			System.out.println("수정할 성적 : ");

			int new_HTML = scan.nextInt();
			scan.nextLine(); // 개행문자(엔터)를 제거하기위해 추가
			Student new_stu = new Student(new_id, new_name, new_JAVA, new_C, new_HTML);
			list.set(tempIndex, new_stu);
			System.out.println("수정완료");
		} else {
			System.out.println("등록된 ID가 없습니다.");
		}
	}

	// 4. 삭제
	public void delete() {
		System.out.println("삭제할 학생 ID를 입력");
		id = scan.nextLine();
		boolean found = false;
		int tempIndex = 0;
		for (int i = 0; i < list.size(); i++) {
			Student stu = list.get(i);
			if (id.equals(stu.getId())) {
				found = true;
				tempIndex = i;
			}
		}
		if (found) {
			list.remove(tempIndex);
			System.out.println("ID가 삭제됨.");
		} else {
			System.out.println("삭제할 ID가 없음");
		}
	}

//5. 저장
	public void save() {
		OutputStream out = null;
		ObjectOutputStream oos = null;
		try {
			out = new FileOutputStream("member.txt");
			oos = new ObjectOutputStream(out);
			oos.writeObject(list);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (Exception e) {
				}
			}
			if (oos != null) {
				try {
					oos.close();
				} catch (Exception e) {
				}
			}
		}
	}

	// 6. 불러오기
	public void invoke() {
		InputStream in = null;
		ObjectInputStream ois = null;
		ArrayList<Student> list = null;
		try {
			in = new FileInputStream("member.txt");
			ois = new ObjectInputStream(in);
			list = (ArrayList<Student>) ois.readObject();
			Iterator it = list.iterator();
			while (it.hasNext()) {
				System.out.println(it.next());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
				}
			}
			if (ois != null) {
				try {
					ois.close();
				} catch (Exception e) {
				}
			}
		}
	}

// 7. 이름순 정렬
	public void namesort() {
		Collections.sort(list);
		for (int i = 0; i < list.size(); i++) {
			System.out.println(
					"ID : " + list.get(i).getId() + " 이름 : " + list.get(i).getName() + " 성적 : " + list.get(i).getJAVA());
		}
	}

// 8. 성적순 정렬
	public void scoresort() {
		list.sort(new Comparator<Student>() {
			@Override
			public int compare(Student num1, Student num2) {
				// TODO Auto-generated method stub
				int score0 = num1.getJAVA();
				int score1 = num2.getJAVA();

				if (score0 == score1)
					return 0;
				else if (score0 < score1)
					return 1;
				else
					return -1;
			}

		});
		for (int i = 0; i < list.size(); i++) {
			System.out.println(
					"ID : " + list.get(i).getId() + " 이름 : " + list.get(i).getName() + " 성적 : " + list.get(i).getJAVA());
		}
	}
}