import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

class EditDialog extends JDialog implements ActionListener {

	private StudentGUIDesign gui;
	private StudentDAO dao;
	private JTextField tf = new JTextField(20);



	private JTextField d_tf_id = new JTextField(20); // id
	private JTextField d_tf_name = new JTextField(20); // 이름
	private JTextField d_tf_JAVA = new JTextField(20); // 성적
	private JTextField d_tf_C = new JTextField(20); // 영어
	private JTextField d_tf_HTML = new JTextField(20); // 수학

	private JLabel d_ja_id = new JLabel("수정 ID");
	private JLabel d_ja_name = new JLabel("이름");
	private JLabel d_ja_JAVA = new JLabel("JAVA");
	private JLabel d_ja_C = new JLabel("C");
	private JLabel d_ja_HTML = new JLabel("HTML");

	private JButton d_bt_check = new JButton("확인");
	private JButton d_bt_ok = new JButton("수 정");
	private JButton d_bt_cancel = new JButton("취 소");
	private StudentGUIDesign stf;

	private JPanel p;
	ImageIcon icon = new ImageIcon("images/editBackground.png");

	EditDialog(JFrame frame, StudentDAO dao) {
		super(frame, "수정", true);
		this.dao = dao;
		Dimension frameSize = this.getSize();
		Dimension windowSize = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation((windowSize.width - frameSize.width) / 3 + 50,
				(windowSize.height - frameSize.height) / 3 + 50);
		this.dialogDesign();
		this.dialogEvent();
		this.setSize(415, 410);
	}

	public void dialogDesign() {
		p = new JPanel() {
			public void paintComponent(Graphics g) {
				g.drawImage(icon.getImage(), 0, 0, null);
				setOpaque(false);
				super.paintComponent(g);
			}
		};
		
		p.setLayout(null);
		this.add(p);
		
		d_ja_id.setSize(80, 25);
		d_ja_id.setLocation(100, 75);
		d_ja_id.setForeground(Color.BLACK);
		p.add(d_ja_id);

		d_ja_name.setSize(80, 25);
		d_ja_name.setLocation(100, 105);
		d_ja_name.setForeground(Color.BLACK);
		p.add(d_ja_name);

		d_ja_JAVA.setSize(80, 25);
		d_ja_JAVA.setLocation(100, 135);
		d_ja_JAVA.setForeground(Color.BLACK);
		p.add(d_ja_JAVA);

		d_ja_C.setSize(80, 25);
		d_ja_C.setLocation(100, 165);
		d_ja_C.setForeground(Color.BLACK);
		p.add(d_ja_C);

		d_ja_HTML.setSize(80, 25);
		d_ja_HTML.setLocation(100, 195);
		d_ja_HTML.setForeground(Color.BLACK);
		p.add(d_ja_HTML);
		// --------------------------------------------
		d_tf_id.setSize(90, 25);
		d_tf_id.setLocation(155, 75);
		p.add(d_tf_id);

		d_tf_name.setSize(90, 25);
		d_tf_name.setLocation(155, 105);
		p.add(d_tf_name);

		d_tf_JAVA.setSize(90, 25);
		d_tf_JAVA.setLocation(155, 135);
		p.add(d_tf_JAVA);

		d_tf_C.setSize(90, 25);
		d_tf_C.setLocation(155, 165);
		p.add(d_tf_C);

		d_tf_HTML.setSize(90, 25);
		d_tf_HTML.setLocation(155, 195);
		p.add(d_tf_HTML);

		p.add(d_bt_check);
		d_bt_check.setBounds(250, 75, 60, 25);

		p.add(d_bt_ok);
		d_bt_ok.setBounds(135, 255, 65, 30);
		p.add(d_bt_cancel);
		d_bt_cancel.setBounds(205, 255, 65, 30);

		d_bt_check.setBackground(new Color(242, 158, 158));
		d_bt_check.setForeground(Color.white);
		d_bt_ok.setBackground(new Color(0, 0, 0));
		d_bt_ok.setForeground(Color.white);
		d_bt_cancel.setBackground(new Color(0, 0, 0));
		d_bt_cancel.setForeground(Color.white);
		d_tf_name.setEditable(false);

		d_tf_JAVA.setEditable(false);
		d_tf_HTML.setEditable(false);
		d_tf_C.setEditable(false);
	}

	public void dialogEvent() {
		d_bt_check.addActionListener(this);
		d_bt_ok.addActionListener(this);
		d_bt_cancel.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == d_bt_ok) {
			boolean found = false;
			int tempIndex = 0;

			for (int i = 0; i < dao.list.size(); i++) {
				Student stu = dao.list.get(i);
				if (d_tf_id.getText().equals(stu.getId())) {
					found = true;
					tempIndex = i;
					break;
				}
			}
			if (found) {

				if (Integer.parseInt(d_tf_JAVA.getText()) >= 0 && Integer.parseInt(d_tf_JAVA.getText()) <= 100
						&& Integer.parseInt(d_tf_C.getText()) >= 0
						&& Integer.parseInt(d_tf_C.getText()) <= 100 && Integer.parseInt(d_tf_HTML.getText()) >= 0
						&& Integer.parseInt(d_tf_HTML.getText()) <= 100) {
					Student new_stu = new Student(d_tf_id.getText(), d_tf_name.getText(),
							Integer.parseInt(d_tf_JAVA.getText()), Integer.parseInt(d_tf_C.getText()),
							Integer.parseInt(d_tf_HTML.getText()));
					dao.list.set(tempIndex, new_stu);
					JOptionPane.showMessageDialog(null, "수정되었습니다", "Message", JOptionPane.OK_CANCEL_OPTION);
					EditDialog.this.setVisible(false);
				} else {
					JOptionPane.showMessageDialog(null, "0부터 100사이의 점수만 입력하세요!!", "Message",
							JOptionPane.OK_CANCEL_OPTION);
				}
			} else {
				d_tf_name.setEditable(false);
				d_tf_JAVA.setEditable(false);
			}
		}

		else if (e.getSource() == d_bt_check) {
			boolean found = false;
			for (int i = 0; i < dao.list.size(); i++) {
				Student stu = dao.list.get(i);
				if (d_tf_id.getText().equals(stu.getId())) {
					d_tf_name.setEditable(true);
					d_tf_JAVA.setEditable(true);
					d_tf_C.setEditable(true);
					d_tf_HTML.setEditable(true);

					d_tf_name.setText(dao.list.get(i).getName());
					d_tf_JAVA.setText("" + dao.list.get(i).getJAVA());
					d_tf_C.setText("" + dao.list.get(i).getC());
					d_tf_HTML.setText("" + dao.list.get(i).getHTML());
					found = true;
					break;
				} else {
					d_tf_name.setEditable(false);
					d_tf_JAVA.setEditable(false);
					d_tf_C.setEditable(false);
					d_tf_HTML.setEditable(false);

					d_tf_name.setText("");
					d_tf_JAVA.setText("");
					d_tf_C.setText("");
					d_tf_HTML.setText("");
				}
			}
			if (!found) {
				JOptionPane.showMessageDialog(null, "일치하는 정보가 없습니다", "", JOptionPane.OK_CANCEL_OPTION);
			}

		} else if (e.getSource() == d_bt_cancel) {
			d_tf_id.setText("");
			d_tf_name.setText("");
			d_tf_JAVA.setText("");
			EditDialog.this.setVisible(false);
		}
	}
}
