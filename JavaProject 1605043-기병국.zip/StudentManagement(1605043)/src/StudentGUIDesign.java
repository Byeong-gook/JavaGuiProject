import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;




public class StudentGUIDesign extends JFrame implements ActionListener, KeyListener, FocusListener {

	private JPanel p; //패널 (배경삽입용)
	ImageIcon img = new ImageIcon("images/GUIBackground.png"); //배경화면 이미지
	
	private JLabel ja_id = new JLabel("ID"); //ID (학번)
	private JLabel ja_name = new JLabel("이름"); //이름 
	private JLabel ja_JAVA = new JLabel("JAVA"); //자바
	private JLabel ja_C = new JLabel("C"); // C
	private JLabel ja_HTML = new JLabel("HTML"); //HTML
	private JLabel ja_Hello = new JLabel("ID를 등록 해주세요~"); //ID (학번)
	
	private JTextField tf_id = new JTextField(20); // ID (학번)
	private JTextField tf_name = new JTextField(20); // 이름
	private JTextField tf_JAVA = new JTextField(20); // JAVA
	private JTextField tf_C = new JTextField(20); // C
	private JTextField tf_HTML = new JTextField(20); // HTML
	
	private JButton bt_input = new JButton("등록"); //등록버튼
	private JButton bt_inquire = new JButton("조회"); //조회버튼
	private JButton bt_update = new JButton("수정"); //수정버튼
	private JButton bt_delete = new JButton("삭제"); //삭제버튼
	private JButton bt_exit = new JButton("종료"); //종료버튼
	
	private StudentDAO dao = new StudentDAO(); // DAO 객체생성
	private EditDialog edit;
	private DeleteDialog delete;
	private InquireDialog inquire;

	StudentGUIDesign() {
		//Dimension Class 특정한 사각형 영역을 관리하게 편리한 클래스이다.
		//보통은 화면의 전체사이즈 정보 또는 특정 Frame이 화면 중앙에 나오게 할때 주로 이용되는 클래스이다.
		Dimension windowSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = this.getSize();
		
		this.setLocation((windowSize.width - frameSize.width) / 3, (windowSize.height - frameSize.height) / 3);
		
		this.setTitle("학생관리 프로그램");
		this.formDesign();
		this.eventHandler();
		this.setSize(535,540);
		this.setVisible(true);
	}
	
	
	public void formDesign() {
		p = new JPanel() {
			public void paintComponent(Graphics g) {
				g.drawImage(img.getImage(), 0, -25, null); //drawImage (이미지객체, x, y좌표, 인터페이스)
				setOpaque(false);
				super.paintComponent(g);
				
				//얼굴
				g.setColor(Color.yellow);
				g.fillOval(50, 150, 45, 45);
				//눈
				g.setColor(Color.BLACK);
				g.fillOval(63, 160, 8, 8);
				g.fillOval(77, 160, 8, 8);
				g.setColor(Color.red);
				g.fillOval(70, 180, 9, 9);
				
			}
		};
		p.setLayout(null);
		this.add(p);
		ja_Hello.setSize(150, 30);
		ja_Hello.setLocation(110, 150);
		ja_Hello.setForeground(Color.BLACK);
		p.add(ja_Hello);
		
		//라벨부분 (폼디자인 정의)
		ja_id.setSize(25, 30);
		ja_id.setLocation(127, 200);
		ja_id.setForeground(Color.BLACK);
		p.add(ja_id);

		ja_name.setSize(35, 30);
		ja_name.setLocation(127, 240);
		ja_name.setForeground(Color.BLACK);
		p.add(ja_name);

		ja_JAVA.setSize(35, 30);
		ja_JAVA.setLocation(127, 280);
		ja_JAVA.setForeground(Color.BLACK);
		p.add(ja_JAVA);

		ja_C.setSize(35, 30);
		ja_C.setLocation(128, 320);
		ja_C.setForeground(Color.BLACK);
		p.add(ja_C);

		ja_HTML.setSize(35, 30);
		ja_HTML.setLocation(128, 360);
		ja_HTML.setForeground(Color.BLACK);
		p.add(ja_HTML);
		
		//텍스트 필드 (폼디자인 정의)
		tf_id.setSize(120, 30);
		tf_id.setLocation(178, 200);
		p.add(tf_id);

		tf_name.setSize(120, 30);
		tf_name.setLocation(178, 240);
		p.add(tf_name);

		tf_JAVA.setSize(120, 30);
		tf_JAVA.setLocation(178, 280);
		p.add(tf_JAVA);

		tf_C.setSize(120, 30);
		tf_C.setLocation(178, 320);
		p.add(tf_C);

		tf_HTML.setSize(120, 30);
		tf_HTML.setLocation(178, 360);
		p.add(tf_HTML);

		//버튼 (크기 및 위치 정의)
		p.add(bt_input);
		bt_input.setBounds(310, 200, 90, 30);
		p.add(bt_inquire);
		bt_inquire.setBounds(310, 240, 90, 30);
		p.add(bt_update);
		bt_update.setBounds(310, 280, 90, 30);
		p.add(bt_delete);
		bt_delete.setBounds(310, 320, 90, 30);
		p.add(bt_exit);
		bt_exit.setBounds(310, 360, 90, 30);

		bt_input.setEnabled(false); 
		tf_name.setEditable(false); //초기화면에서는 버튼이 비활성화상태이지만                             
		tf_JAVA.setEditable(false); //사용자가 내용을 입력하면 버튼과 텍스트필드가 활성화되도록 구현하였습니다. 
		tf_C.setEditable(false);
		tf_HTML.setEditable(false);
		
        //버튼 (폼디자인 정의)		
		bt_input.setBackground(new Color(200, 255, 137));
		bt_input.setForeground(Color.BLACK);
		bt_inquire.setBackground(new Color(200, 255, 137));
		bt_inquire.setForeground(Color.BLACK);
		bt_update.setBackground(new Color(200, 255, 137));
		bt_update.setForeground(Color.BLACK);
		bt_delete.setBackground(new Color(200, 255, 137));
		bt_delete.setForeground(Color.BLACK);
		bt_exit.setBackground(new Color(200, 255, 137));
		bt_exit.setForeground(Color.BLACK);
		
	
	}
	
	public void eventHandler() {
		tf_id.addFocusListener(this);
		tf_name.addFocusListener(this);
		tf_JAVA.addFocusListener(this);
		tf_C.addFocusListener(this);
		tf_HTML.addFocusListener(this);

		tf_JAVA.addKeyListener(this);

		bt_input.addActionListener(this);
		bt_inquire.addActionListener(this);
		bt_update.addActionListener(this);
		bt_delete.addActionListener(this);
		bt_exit.addActionListener(this);
	}
	public static void main(String[] args) {
		new StudentGUIDesign();
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == bt_input) {
			// StudentDAO에 있는 등록 메뉴를 처리하는 메소드, insert()에 입력받은 학생 데이터를 전달하여 등록한다.
			for (int i = 0; i < dao.list.size(); i++) {
				Student stu = dao.list.get(i);
				if (tf_id.getText().equals(stu.getId())) {
					JOptionPane.showMessageDialog(null, "이미 존재하는 학번입니다. 다시입력하세요!!", "Message",
							JOptionPane.OK_CANCEL_OPTION);
					tf_id.setText("");
					return;
				}
			}
			if (Integer.parseInt(tf_JAVA.getText()) >= 0 && Integer.parseInt(tf_JAVA.getText()) <= 100
					&& Integer.parseInt(tf_C.getText()) >= 0 && Integer.parseInt(tf_C.getText()) <= 100
					&& Integer.parseInt(tf_HTML.getText()) >= 0 && Integer.parseInt(tf_HTML.getText()) <= 100) {
				dao.input(tf_id.getText(), tf_name.getText(), Integer.parseInt(tf_JAVA.getText()),
						Integer.parseInt(tf_C.getText()), Integer.parseInt(tf_HTML.getText()));

				JOptionPane.showMessageDialog(null, "등록되었습니다!!", "Message", JOptionPane.OK_CANCEL_OPTION);
				tf_name.setEditable(false);
				tf_JAVA.setEditable(false);
				tf_C.setEditable(false);
				tf_HTML.setEditable(false);
				tf_id.setText("");
				tf_name.setText("");
				tf_JAVA.setText("");
				tf_C.setText("");
				tf_HTML.setText("");
			} else {
				JOptionPane.showMessageDialog(null, "0부터 100사이의 점수만 입력하세요!!", "Message", JOptionPane.OK_CANCEL_OPTION);
			}
			// 추가적으로 다른 버튼을 활성화
		}
		// -----------------------------------------------------------------------------------------------------------------------------------조회
		else if (e.getSource() == bt_inquire) {
			inquire = new InquireDialog(this, dao);
			inquire.setVisible(true);
		}
		// -----------------------------------------------------------------------------------------------------------------------------------수정
		else if (e.getSource() == bt_update) {
			edit = new EditDialog(this, dao);
			edit.setVisible(true);
		}
		// -----------------------------------------------------------------------------------------------------------------------------------삭제
		else if (e.getSource() == bt_delete) {
			delete = new DeleteDialog(this, dao);
			delete.setVisible(true);
		}
		// -----------------------------------------------------------------------------------------------------------------------------------종료
		else if (e.getSource() == bt_exit) {
			System.exit(0);
		}
		
	}

	@Override
	public void focusGained(FocusEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void focusLost(FocusEvent e) {
		if (e.getSource().equals(tf_id)) {
			if (tf_id.getText().equals("")) {
			} else {
				tf_name.setEditable(true);
			}
		} else if (e.getSource().equals(tf_name)) {
			if (tf_name.getText().equals("")) {
			} else
				tf_JAVA.setEditable(true);
		} else if (e.getSource().equals(tf_JAVA)) {
			if (tf_JAVA.getText().equals("")) {
			} else {
				tf_C.setEditable(true);
			}
		} else if (e.getSource().equals(tf_C)) {
			if (tf_C.getText().equals("")) {
			} else {
				tf_HTML.setEditable(true);
			}
		} else if (e.getSource().equals(tf_HTML)) {
			if (tf_HTML.getText().equals("")) {
			} else {

				bt_input.setEnabled(true);
				bt_input.requestFocus();
			}
		}
	}
}
